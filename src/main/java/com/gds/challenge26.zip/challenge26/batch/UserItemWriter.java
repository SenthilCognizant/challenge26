package com.gds.challenge26.batch;

import com.gds.challenge26.model.User;
import com.gds.challenge26.repository.UserRepository;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;

import java.util.List;


public class UserItemWriter implements ItemWriter<User> {

    private final UserRepository userRepository;

    public UserItemWriter(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void write(Chunk<? extends User> chunk) {
        List<?extends User> users = chunk.getItems();
        userRepository.saveAll(users);
    }
}
