package com.gds.challenge26.batch;

import com.gds.challenge26.model.User;
import com.gds.challenge26.model.UserDto;
import org.springframework.batch.item.ItemProcessor;

public class UserItemProcessor implements ItemProcessor<UserDto, User> {

    @Override
    public User process(UserDto dto){
        return new User(dto.getName());
    }
}
