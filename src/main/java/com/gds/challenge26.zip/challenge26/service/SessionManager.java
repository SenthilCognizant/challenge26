package com.gds.challenge26.service;

import com.gds.challenge26.model.User;
import com.gds.challenge26.model.UserDto;
import com.gds.challenge26.repository.UserRepository;
import com.gds.challenge26.util.MenuProvider;

import java.util.List;
import java.util.Scanner;

public class SessionManager {
    private final SessionService sessionService;

    public SessionManager(SessionService sessionService) {
        this.sessionService = sessionService;
    }

    public void handleSession(String initiatorName) {

        Scanner scanner = new Scanner(System.in);

        List<UserDto> users = sessionService.getUsers();
        System.out.print("List of users " + users);

        if(sessionService.isUserPresent(initiatorName)) {
            sessionService.initUser(initiatorName);
            while (true) {
                MenuProvider.displayMenu();

                int choice = 0;
                try {
                    choice = Integer.parseInt(scanner.nextLine());
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                sessionOperation(choice);
            }
        }
        else{
            System.out.print("Entered session initiator not Authorized /n");
            sessionService.endSession();
            System.out.println("Exiting the session application.");
            System.exit(0);
        }
    }

    public void sessionOperation(int choice) {

        Scanner scanner = new Scanner(System.in);

        switch (choice) {
            case 1:
                System.out.print("Enter the name of the participant to invite: ");
                String participant = scanner.nextLine();
                sessionService.invite(participant);
                break;
            case 2:
                System.out.print("Enter your name (participant): ");
                String responder = scanner.nextLine();
                System.out.print("Enter your choice of restaurant: ");
                String response = scanner.nextLine();
                sessionService.submitResponse(responder, response);
                break;
            case 3:
                System.out.print("Participant and the choice of restaurant");
                sessionService.restaurantChoices();
                break;
            case 4:
                System.out.print("Enter your name (initiator) to end the session: ");
                String endInitiator = scanner.nextLine();
                sessionService.endSessionByInitiator(endInitiator);
                break;
            case 5:
                sessionService.randomlyPickAnswer();
                break;
            case 6:
                System.out.println("Exiting the session application.");
                System.exit(0);
            default:
                System.out.println("Invalid option. Please enter to retry.");
                scanner.nextLine(); // Consume the newline character
        }
    }
}
