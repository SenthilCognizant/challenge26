package com.gds.challenge26.service;

import com.gds.challenge26.model.User;
import com.gds.challenge26.model.UserDto;
import com.gds.challenge26.repository.UserRepository;
import lombok.Getter;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Getter
@Service
public class SessionService {
    private String initiator;
    private List<String> participants =new ArrayList<>();
    private List<String> responses = new ArrayList<>();
    private boolean ended;

    private final UserRepository repository;

    public boolean isEnded(){
        return ended;
    }

    public List<String> getParticipants(){
        return participants;
    }

    public List<String> getResponses(){
        return responses;
    }

    public SessionService(UserRepository repository) {
        this.repository = repository;
    }

    public List<UserDto> getUsers() {
       List<User> users =  repository.findAll();

        return users.stream()
        .map(user -> new UserDto(user.getName()))
        .toList();
    }

    public boolean isUserPresent(String name){
        return repository.existsByName(name);
    }

    public void initUser(String name){
        this.initiator = name;
    }

    public void invite(String participant) {
        if (!ended) {
            participants.add(participant);
            System.out.println(participant + " has been invited to the session.");
        } else {
            System.out.println("The session has ended. You cannot invite more participants.");
        }
    }

    public void submitResponse(String participant, String response) {
        if (!ended && participants.contains(participant)) {
            responses.add(participant + ": " + response);
            System.out.println(participant + " submitted response: " + response);
        } else {
            System.out.println("Invalid participant or the session has ended.");
        }
    }

    public void endSessionByInitiator(String initiator) {
        if (initiator.equals(this.initiator)) {
            System.out.println("The session has been ended by the initiator.");
            ended = true;
        } else {
            System.out.println("Only the initiator can end the session.");
        }
    }

    public void endSession() {
            System.out.println("The session has been ended.");
            ended = true;
    }

    public String randomlyPickAnswer() {
        if (ended) {
            if (responses.isEmpty()) {
                System.out.println("No responses submitted. Cannot pick an answer.");
            } else {
                Random random = new Random();
                int randomIndex = random.nextInt(responses.size());
                String pickedAnswer = responses.get(randomIndex);
                System.out.println("Randomly picked answer: " + pickedAnswer);
                return pickedAnswer;
            }
        } else {
            System.out.println("The meeting is still ongoing. Cannot pick an answer yet.");
        }
        return null;
    }

    public List<String> restaurantChoices() {
        if (!ended) {
            if (responses.isEmpty()) {
                System.out.println("\nNo responses submitted. Cannot pick an answer.");
            } else {
                for(String choice : responses)
                    System.out.println("\nchoice: " + choice);
                return responses;
            }
        } else {
            System.out.println("The session ended.");
        }
        return null;
    }
}
