package com.gds.challenge26.util;

public class MenuProvider {
    public static void displayMenu() {
        System.out.println("\n1. Invite participant");
        System.out.println("2. Submit response");
        System.out.println("3. Choice of Restaurant made");
        System.out.println("4. End session");
        System.out.println("5. Randomly pick answer");
        System.out.println("6. Exit");

        System.out.print("Choose an option: ");
    }
}
