package com.gds.challenge26.controller;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.web.bind.annotation.*;


@Slf4j
@RestController
@RequestMapping("/batch")
@Tag(name = "Batch APIs")
public class BatchController {

    private final JobLauncher jobLauncher;
    private final Job job;

    public BatchController(JobLauncher jobLauncher, Job job) {
        this.jobLauncher = jobLauncher;
        this.job = job;
    }

    @Operation(summary = "Upload user csv file")
    @PostMapping("/upload")
    public String upload() throws Exception {

        Resource resource = new ClassPathResource("users.csv");
        JobParameters params = new JobParametersBuilder()
                .addString("filePath", resource.getFile().getAbsolutePath())
                .addLong("run.id", System.currentTimeMillis())
                .toJobParameters();

        jobLauncher.run(job, params);
//        log.info("Users imported successfully!");
        return "Users imported successfully!";

    }
}
