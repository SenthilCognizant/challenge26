package com.gds.challenge26;

import com.gds.challenge26.service.SessionManager;
import com.gds.challenge26.service.SessionService;
import com.gds.challenge26.util.CommandLineInput;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableBatchProcessing
public class Challenge26Application {

    public static void main(String[] args) {

        SpringApplication.run(Challenge26Application.class, args);

    }
    @Bean
    CommandLineRunner commandLineRunner(SessionService sessionService) {
        return args -> {
            String initiator = CommandLineInput.initiateCommandLine();
            SessionManager sessionManager = new SessionManager(sessionService);
            sessionManager.handleSession(initiator);
        };
    }
}
